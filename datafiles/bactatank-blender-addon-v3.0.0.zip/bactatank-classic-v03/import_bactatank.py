# Import Struct Unpack and Unpack From
from struct import unpack, unpack_from

# Read String Function
def readString(data, offset):
    string = ""
    currentCharacter = unpack_from("c", data, offset)[0]
    string += currentCharacter.decode("utf-8")
    offset += 1
    while True:
        if (currentCharacter == b"\x00"):
            break
        else:
            currentCharacter = unpack_from("c", data, offset)[0]
            offset += 1
            string += currentCharacter.decode("utf-8")
        
    return [string, offset]

def bactaTankMesh(filepath):
    # Imports
    import time
    import bpy
    import math
    from . import tristrip
    import bmesh

    t = time.time()
    ttm_name = bpy.path.display_name_from_filepath(filepath)

    # Load Data
    data = bytearray()
    with open(filepath, 'rb') as file:
        data = file.read()

    # Offset
    offset = 0

    # BactaTankMesh and PCGHG
    magic = readString(data, offset) # BactaTankMesh
    offset = magic[1]
    version = readString(data, offset) # PCGHG
    offset = version[1]

    # Check version is 0.1
    version = unpack_from("f", data, offset)[0]
    #if version != 0.4:
    #    return {'CANCELLED'}

    offset += 4

    # Read Bones
    bonesHeader = readString(data, offset) # Bones
    offset = bonesHeader[1]
    boneCount = unpack_from("i", data, offset)[0]
    offset += 4

    # Bones Array
    bones = [  ]

    for i in range(boneCount):
        bone = readString(data, offset)
        bones.append(bone[0])
        offset = bone[1]

    # Mesh Header
    meshHeader = readString(data, offset) # Mesh
    offset = meshHeader[1]

    # Get Triangle Count and Vertex Count
    triangleCount = unpack_from("i", data, offset)[0]
    vertexCount = unpack_from("i", data, offset + 4)[0]
    offset += 8

    # Bone Links
    boneLinks = []
    for i in range(8):
        boneLinks.append(unpack_from("b", data, offset)[0])
        offset += 1

    # Mesh Attributes Header
    meshAttributesHeader = readString(data, offset) # MeshAttributes
    offset = meshAttributesHeader[1]

    # Mesh Attributes
    meshAttributesCount = unpack_from("i", data, offset)[0]
    offset += 4

    for i in range(meshAttributesCount):
        offset = readString(data, offset)[1]

    # Vertex Attributes
    vertices = []
    normals = []
    uvs = []
    blendIndices = []
    blendWeights = []

    # Vertices
    offset = readString(data, offset)[1]
    
    # Position
    offset = readString(data, offset)[1]
    for i in range(vertexCount):
        vertex = [0, 0, 0]
        vertex[0] = -unpack_from("f", data, offset)[0]
        vertex[1] = unpack_from("f", data, offset + 4)[0]
        vertex[2] = unpack_from("f", data, offset + 8)[0]
        offset += 12
        vertices.append(vertex)
    
    # Normal
    offset = readString(data, offset)[1]
    for i in range(vertexCount):
        normal = [0, 0, 0]
        normal[0] = -unpack_from("f", data, offset)[0]
        normal[0] = unpack_from("f", data, offset + 4)[0]
        normal[0] = unpack_from("f", data, offset + 8)[0]
        offset += 4
        normals.append(normal)
    
    # Colour
    offset = readString(data, offset)[1]
    for i in range(vertexCount):
        offset += 4
    
    # UVs
    offset = readString(data, offset)[1]
    for i in range(vertexCount):
        tex = [0, 0]
        tex[0] = unpack_from("f", data, offset + 0)[0]
        tex[1] = unpack_from("f", data, offset + 4)[0]
        offset += 8
        uvs.append(tex)
    
    # Blend Indices
    offset = readString(data, offset)[1]
    for i in range(vertexCount):
        blendIndex = [0, 0, 0, 0]
        blendIndex[0] = unpack_from("b", data, offset + 0)[0]
        blendIndex[1] = unpack_from("b", data, offset + 1)[0]
        blendIndex[2] = unpack_from("b", data, offset + 2)[0]
        blendIndex[3] = 0
        offset += 4
        blendIndices.append(blendIndex)
    
    # Blend Weights
    offset = readString(data, offset)[1]
    for i in range(vertexCount):
        blendWeight = [0, 0, 0, 0]
        blendWeight[0] = unpack_from("B", data, offset + 0)[0] / 255
        blendWeight[1] = unpack_from("B", data, offset + 1)[0] / 255
        blendWeight[2] = unpack_from("B", data, offset + 2)[0] / 255
        blendWeight[3] = unpack_from("B", data, offset + 3)[0] / 255
        offset += 4
        blendWeights.append(blendWeight)
    
    # Triangles
    offset = readString(data, offset)[1]
    
    # Triangles Array
    triangles = []
    for i in range(triangleCount+2):
        triangles.append(unpack_from("H", data, offset)[0])
        offset += 2

    # Dynamic Buffers
    offset = readString(data, offset)[1]

    # Dynamic Buffer Count
    dynamicBufferCount = unpack_from("i", data, offset)[0]
    offset += 4

    # Dynamic Buffers Loop
    dynamicBuffers = [  ]
    for i in range(dynamicBufferCount):
        dynamicBuffer = [  ]
        for v in range(vertexCount):
            vertex = [ 0, 0, 0 ]
            vertex[0] = -unpack_from("f", data, offset)[0]
            vertex[1] = unpack_from("f", data, offset + 4)[0]
            vertex[2] = unpack_from("f", data, offset + 8)[0]
            offset += 12
            dynamicBuffer.append(vertex)
        dynamicBuffers.append(dynamicBuffer)
    
    # Triangulate Triangles
    triangles = tristrip.triangulate([triangles])

    # Deselect All Meshes
    for ob in bpy.context.selected_objects:
        ob.select_set(False)

    # Create Mesh
    mesh = bpy.data.meshes.new("Mesh")

    # Create New Object
    obj = bpy.data.objects.new(ttm_name, mesh)
    bpy.context.collection.objects.link(obj)
    bpy.context.view_layer.objects.active = obj
    obj.select_set(True)

    # Create new BMesh
    mesh = bmesh.new()
    mesh.from_mesh(obj.data)

    # Add Vertices To Mesh
    for vertex in vertices:
        mesh.verts.new((vertex[0], vertex[1], vertex[2]))
    
    # Ensure lookup table
    mesh.verts.ensure_lookup_table()
    mesh.faces.ensure_lookup_table()

    # Add Triangles
    for triangle in triangles:
        mesh.faces.ensure_lookup_table()
        mesh.faces.new([mesh.verts[list (triangle)[2]], mesh.verts[list (triangle)[1]], mesh.verts[list (triangle)[0]]])
        mesh.faces.ensure_lookup_table()
    
    # Update Normals
    mesh.normal_update()
    mesh.verts.index_update()
    mesh.verts.ensure_lookup_table()
    mesh.faces.ensure_lookup_table()

    # Create UVSet1
    uvSet1 = mesh.loops.layers.uv.new("uvSet1")
    for face in mesh.faces:
        for loop in face.loops:
            loop[uvSet1].uv = [uvs[loop.vert.index][0], -uvs[loop.vert.index][1]]
    
    # Apply Mesh
    mesh.to_mesh(obj.data)
    
    # Create Vertex Groups
    vertex_groups = []
    for i, bone in enumerate(boneLinks):
        if bone == -1:
            continue
        print(bone)
        vertex_groups.append(bpy.context.active_object.vertex_groups.new(name=bones[bone]))
    
    # Apply Skinning Data
    if len(vertex_groups) > 0:
        for vert in obj.data.vertices:
            vertex = []
            vertex.append(vert.index)
            vertex_groups[blendIndices[vert.index][0]].add(vertex, blendWeights[vert.index][0], 'ADD')
            vertex_groups[blendIndices[vert.index][1]].add(vertex, blendWeights[vert.index][1], 'ADD')
            vertex_groups[blendIndices[vert.index][2]].add(vertex, blendWeights[vert.index][2], 'ADD')

    # Check if dynamic buffers exist
    if len(dynamicBuffers) > 0:
        # Create Basis Shape Key
        sk_basis = obj.shape_key_add(name="Basis")
        sk_basis.interpolation = 'KEY_LINEAR'
        obj.data.shape_keys.use_relative = True

        # Dynamic Buffers
        for i, dynamicBuffer in enumerate(dynamicBuffers):
            # Create new shape key
            sk = obj.shape_key_add(name="Pose " + str(i))
            sk.interpolation = 'KEY_LINEAR'
            sk.slider_min = 0
            sk.slider_max = 1
            sk.value = 0
            sk.relative_key = sk_basis

            # Position
            for v, vert in enumerate(mesh.verts):
                index = vertices.index([sk.data[v].co.x, sk.data[v].co.y, sk.data[v].co.z])
                #print(str(sk.data[v].co.x) + " " + str(vertices[index][0]))
                #print(str(v) + " " + str(index))
                sk.data[v].co.x += dynamicBuffer[index][0]
                sk.data[v].co.y += dynamicBuffer[index][1]
                sk.data[v].co.z += dynamicBuffer[index][2]

    # Smooth Shading I Think
    mesh = obj.data
    for f in mesh.polygons:
        f.use_smooth = True

    # Auto Parent To Armature
    object_list = bpy.context.scene.objects
    armature_list = [o for o in object_list if o.type=='ARMATURE']

    # Check if there is an armature
    if len(armature_list) > 0 and len(vertex_groups) > 0:
        obj.parent = armature_list[0]
        obj.parent_type = 'ARMATURE'
    else:
        # Rotate 90 degrees
        bpy.context.active_object.rotation_euler[0] = math.radians(90)

    print("\nSuccessfully imported %r in %.3f sec" % (filepath, time.time() - t))

    return {'FINISHED'}

def importMesh(operator, context, filepath=""):
    return bactaTankMesh(filepath)

def bactaTankArmature(filepath):
    # Imports
    import time
    import bpy
    import math
    from . import tristrip

    t = time.time()
    ttm_name = bpy.path.display_name_from_filepath(filepath)

    # Load Data
    data = bytearray()
    with open(filepath, 'rb') as file:
        data = file.read()

    # Offset
    offset = 0

    # BactaTankArmature and PCGHG
    offset = readString(data, offset)[1] # BactaTankArmature
    offset = readString(data, offset)[1] # PCGHG

    # Check version is 0.4
    version = unpack_from("f", data, offset)[0]
    offset += 4

    # Bones Header
    offset = readString(data, offset)[1] # Bones

    # Bone Count
    boneCount = unpack_from("i", data, offset)[0]
    offset += 4
    print(boneCount)

    # Create Armature
    armature = bpy.ops.object.armature_add()

    # Go into Edit Mode
    bpy.ops.object.mode_set(mode='EDIT', toggle=False)
    armatureObject = bpy.context.active_object
    bones = armatureObject.data.edit_bones
    
    for bone in bones:
        armatureObject.data.edit_bones.remove(bone)

    # Bone Count
    for i in range(boneCount):
        # Bone Name
        boneName = readString(data, offset)
        offset = boneName[1]

        # Parent Index
        boneParentIndex = unpack_from("i", data, offset)[0]
        offset += 4

        # Bone Position
        boneX = -unpack_from("f", data, offset + 48)[0]
        boneY = unpack_from("f", data, offset + 52)[0]
        boneZ = unpack_from("f", data, offset + 56)[0]
        offset += 64

        # Create Bone
        bone = bones.new(boneName[0])
        bone.head = (boneX, boneY, boneZ)
        bone.tail = (boneX, boneY + 0.02, boneZ)

        # Set Parent
        if boneParentIndex != -1:
            bone.parent = bones[boneParentIndex]
    
    # Rotate 90 degrees
    bpy.context.active_object.rotation_euler[0] = math.radians(90)
    
    # Go into Object mode
    bpy.ops.object.mode_set(mode='OBJECT', toggle=False)

def importArmature(operator, context, filepath=""):
    return bactaTankArmature(filepath)